/* $Id$ */

/**
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements. See the NOTICE file distributed with
* this work for additional information regarding copyright ownership.
* The ASF licenses this file to You under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with
* the License. You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package org.apache.manifoldcf.agents.output.amazoncloudsearch;

/** Parameters for AmazonCloudSearch output connector.
 */
public class AmazonCloudSearchConfig {

  // Configuration parameters
  public static final String SERVER_HOST="serverhost";
  public static final String SERVER_PATH="serverpath";
  public static final String PROXY_PROTOCOL="proxyprotocol";
  public static final String PROXY_HOST="proxyhost";
  public static final String PROXY_PORT="proxyport";
    
  public static final String SERVER_HOST_DEFAULT = "";
  public static final String SERVER_PATH_DEFAULT = "/2013-01-01/documents/batch";
  public static final String PROXY_PROTOCOL_DEFAULT = "http";
  public static final String PROXY_HOST_DEFAULT = "";
  public static final String PROXY_PORT_DEFAULT = "";
  
  // Specification nodes and values
  
}
